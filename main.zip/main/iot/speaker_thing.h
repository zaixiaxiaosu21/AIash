#pragma once

#include "things.h"

thing_t *speaker_thing_create(void);