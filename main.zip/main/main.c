#include "application.h"

void app_main(void)
{
    application_init();
}