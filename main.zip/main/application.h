#pragma once

void application_init(void);